#!/usr/bin/env python3
# -*- coding:utf-8 -*-
# Copyright (c) Megvii, Inc. and its affiliates.

import os

from yolox.exp import Exp as MyExp

class Exp(MyExp):
    def __init__(self):
        super(Exp, self).__init__()
        '''
        depth 和 width对应的不同模型类型
        tiny: [0.33, 0.375],
        s: [0.33, 0.5],
        m: [0.67, 0.75],
        l: [1.0, 1.0],
        x: [1.33, 1.25]}
        
        '''
        self.depth = 1.0   
        self.width = 1.0
        self.exp_name = os.path.split(os.path.realpath(__file__))[1].split(".")[0]
        
        # Define yourself dataset path
        self.data_dir = "/home/xx/yolox/YOLOX-main/kaggle_dataset"   #check，换成自己的数据集路径
        self.train_ann = "train.json"
        self.val_ann = "valid.json"

        self.num_classes = 1   #目标类别数 为 1

        self.max_epoch = 100  #总共训练的轮次
        self.data_num_workers = 8  #几个线程
        self.eval_interval = 20   #训练每隔几个epoch 验证一次
        
        #self.mosaic_prob = 1.0   # mosaic增强的概率
        self.translate = 0.1      # 仿射变换
        #self.mixup_prob = 0.5    # mixup增强的概率
        #self.hsv_prob = 0.5      #色彩变换的概率
        self.flip_prob = 0.5     #翻转的概率
        self.no_aug_epochs = 10   #不做数据增强的轮次
        
        self.input_size = (800, 1280)   # 输入尺度大小(h,w)
        self.multiscale_range = 5 
        #self.mosaic_scale = (0.5, 1.5) #mosiac 增强 拼接尺度范围   
        #self.random_size = (25, 40)    # 随机尺度范围 （a,b）:a*32 到 b*32
        self.basic_lr_per_img = 0.01 / 64.0    # 64对应每个batchsize数量，需要调整
        
        # test config
        self.test_size = (800, 1280)   #测试尺度大小
        self.test_conf = 0.01
        self.nmsthre = 0.4
