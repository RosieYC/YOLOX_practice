第一步：

下载yolox
下载代码  或者   找小享直接用老师的代码
$ git clone https://github.com/Megvii-BaseDetection/YOLOX 

2.  安装所需的第三方库
$ cd YOLOX
$ pip install -r requirements.txt

代码编译
$ python setup.py develop

第二步：

数据格式准备  或者 直接用老师准备好的数据

运行脚本prepare_data.py :记得修改自己的数据路径
$ python prepare_data.py


第三步：

网址  : https://github.com/Megvii-BaseDetection/YOLOX
下载预训练权重 放到pretrain_models文件夹下
Yolox_s :https://github.com/Megvii-BaseDetection/YOLOX/releases/download/0.1.1rc0/yolox_s.pth
Yolox_m: https://github.com/Megvii-BaseDetection/YOLOX/releases/download/0.1.1rc0/yolox_m.pth 
Yolox_l: https://github.com/Megvii-BaseDetection/YOLOX/releases/download/0.1.1rc0/yolox_l.pth


第四步：配置文件修改/发你的代码已经修改好了，可以看下

1. 修改./yolox/data/datasets目录下的 coco_classes.py 和 voc_classes.py
定义一个目标名称
2. 在代码目录下新建一个starfish_yolox_l.py 作为配置文件（文件名随意后面脚本运行记得对应）
3. starfish_yolox_s.py 作为配置文件（文件名随意后面脚本运行记得对应）

第五步： 愉快的训练过程

可以直接运行sh kaggle_run.sh 

或者 
$python tools/train.py -n yolox-s -c ./pretrain_models/yolox_s.pth -b 64 -f ./starfish_yolox_s.py  -d 1


